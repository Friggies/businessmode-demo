# Changelog

## 0.1.0-preview.0 — unreleased

- First standalone TypeScript/JavaScript ESM preview candidate.
- Generated API types, public/human/machine authentication, request IDs and
  explicit idempotency-key support. No automatic retries.
- Access Code creation accepts optional exact promo strings. Timestamp strings
  retain their supplied offset.
- Payment helpers are generated from the shared source and included in the
  package. No private workspace package is required at runtime.
- Preview support targets Node.js 24 and 26, using native fetch.

This version is prepared for publication; its presence here does not mean it has
been published. Preview consumers should pin an exact version. Breaking API/type
changes require a documented version bump and upgrade notes before release.
