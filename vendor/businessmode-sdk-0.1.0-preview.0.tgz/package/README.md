# @businessmode/sdk

A small TypeScript/JavaScript client generated from the BusinessMode OpenAPI
contract. Uses native `fetch` through `openapi-fetch`.

## Preview and support

`0.1.0-preview.0` is an unpublished release candidate. After the first approved
publication, install and pin that exact version:

```sh
npm install --save-exact @businessmode/sdk@0.1.0-preview.0
```

The supported preview environment is server-side ESM on Node.js 24 or 26, with
TypeScript 6.0.2 checked by CI. Browser, CommonJS, older Node and other TypeScript
versions are not part of the initial support promise. No separate framework
integration, background refresh, caching or retry service is included.

The three factories select authentication, not endpoint permissions. Generated
types reflect the API contract; the API checks authorization for every operation.
The preview includes the existing human/public factories to preserve Product
compatibility. Customer backends should normally use `createMachineClient` for
access checks, seats, invitation redemption and Access Code/promo redemption.
Keep API keys on your backend. Use your existing BusinessMode support channel for
integration issues and include the SDK version and request ID, never credentials.

Pass a base URL that includes `/v1`:

```ts
import { createHumanClient, createIdempotencyKey, createMachineClient } from "@businessmode/sdk";

const human = createHumanClient({
    baseUrl: "https://api.businessmode.io/v1",
    getAccessToken: () =>
        supabase.auth.getSession().then(({ data }) => data.session?.access_token ?? ""),
});

await human.POST("/accounts", {
    body: { name: "Acme Engineering" },
});

await human.POST("/accounts/{accountId}/projects", {
    params: { path: { accountId } },
    body: { name: "Production" },
});
```

The human token callback runs before every request, allowing Supabase token
refresh. Machine clients attach one `bm_sk_` bearer:

```ts
const machine = createMachineClient({
    baseUrl: "https://api.businessmode.io/v1",
    apiKey: process.env.BUSINESSMODE_API_KEY!,
});

const assignmentKey = createIdempotencyKey();
await machine.POST("/licenses/{licenseId}/assignments", {
    params: { path: { licenseId } },
    headers: { "Idempotency-Key": assignmentKey },
    body: { externalUserId: "customer_user_123" },
});

await machine.GET("/access", {
    params: {
        query: {
            externalUserId: "customer_user_123",
            entitlementKey: "premium",
        },
    },
});
```

For one ordinary covered call the SDK supplies a fresh UUID
`Idempotency-Key`. It does not retry requests. When the caller wants to retry
an ambiguous transport result, generate one key first and explicitly reuse it
across every attempt. This applies to Stripe Checkout as well as PostgreSQL
create mutations.

Customer invitation and access-code redemption remain naturally
domain-idempotent and do not receive an automatic key:

```ts
await machine.POST("/invitations/redeem", {
    body: { token: invitationToken, externalUserId: "customer_user_123" },
});

await machine.POST("/access-codes/redeem", {
    body: { code: accessCode, externalUserId: "customer_user_456" },
});
```

Stripe Checkout is retry-safe with the same explicit pattern:

```ts
const checkoutKey = createIdempotencyKey();

await human.POST("/accounts/{accountId}/billing/checkout", {
    params: { path: { accountId } },
    headers: { "Idempotency-Key": checkoutKey },
    body: { plan: "growth", billingInterval: "year" },
});
```

If that call has an ambiguous transport result, repeat it with the same
`checkoutKey`, account path, and body. The Billing Portal route intentionally
creates a fresh short-lived navigation session and does not use this contract.

## Time and error behavior

Timestamp fields are ISO strings with an explicit offset, for example
`2027-01-01T00:15:00+05:45` or `2026-12-31T18:30:00Z`. The SDK sends the supplied
string unchanged; it does not infer the caller's timezone. Convert a local
calendar input to an unambiguous instant in the application before sending it.
Promo strings likewise retain their exact case and whitespace.

Non-success HTTP responses return `error` and `response`; network/transport
failures reject the call. Inspect `response.status`, `getRequestId(response)`
and `Retry-After` where supplied. A second ordinary call gets a new automatic
idempotency key, so an uncertain mutation retry must explicitly retain its key.

## Cancellation and deadlines

Pass a fetch `signal` to a request, for example:

```ts
const result = await machine.GET("/access", {
    params: { query: { externalUserId: "customer_user_123", entitlementKey: "premium" } },
    signal: AbortSignal.timeout(10_000),
});
if (result.error !== undefined) {
    // HTTP failure: do not interpret this as a successful access decision.
    throw new Error(`Access check failed (${result.response.status})`);
}
```

An aborted or timed-out mutation may already have reached the server. Keep its
explicit idempotency key and identical payload if you retry. The SDK imposes no
automatic timeout or retry policy.

## Compatibility and releases

Preview versions may contain breaking changes. Pin an exact version and review
CHANGELOG.md before upgrading. The API remains authoritative for access, seats,
expiry and payments; the SDK does not duplicate those rules. Timestamp values and
promo strings are passed through unchanged. Only `openapi-fetch` is required at
runtime; the payment helpers ship in this package and use the same generated
source as the API.

The package uses the repository's ISC license declaration. Publication is a
separate reviewed release; merging application changes does not publish to npm.
