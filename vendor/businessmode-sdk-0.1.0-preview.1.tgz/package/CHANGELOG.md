# Changelog

## 0.1.0-preview.1 — unreleased

- Authenticated requests stay on the configured API origin, reject empty
  credentials, refuse redirects and bypass fetch caches. These checks can reject
  integrations that previously changed origins or relied on redirects; configure
  the final API URL and use a separate client for each origin.
- Customer-first quickstart documents redemption, fail-closed access checks,
  server-side identity, errors, deadlines and the public Next.js demo.
- README TypeScript examples compile in the standalone consumer check. Credential
  isolation and a real HTTP redirect test run in both Node 24/26 SDK CI jobs.
- This candidate supersedes the unpublished preview.0 archive bundled in the demo.

## 0.1.0-preview.0 — internal candidate, not published

- First standalone TypeScript/JavaScript ESM preview candidate.
- Generated API types, public/human/machine authentication, request IDs and
  explicit idempotency-key support. No automatic retries.
- Access Code creation accepts optional exact promo strings. Timestamp strings
  retain their supplied offset.
- Payment helpers are generated from the shared source and included in the
  package. No private workspace package is required at runtime.
- Preview support targets Node.js 24 and 26, using native fetch.

A version listed here is not necessarily published. Preview consumers should pin
an exact published version. Breaking API/type changes require a documented version
bump and upgrade notes before release.
