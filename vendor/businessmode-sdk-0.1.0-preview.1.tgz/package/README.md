# @businessmode/sdk

A small, typed JavaScript/TypeScript client for BusinessMode: redeem access codes,
assign seats, and check whether a user can use a feature. Your app owns identity;
BusinessMode manages company access. Types are generated from the API contract.

**Preview:** `0.1.0-preview.1` is currently an unpublished release candidate.
After publication, install the exact version:

```sh
npm install --save-exact @businessmode/sdk@0.1.0-preview.1
```

Supports **server-side ESM on Node.js 24 or 26**. TypeScript 6.0.2 is checked in CI.
Browser integrations, CommonJS, other runtimes and other TypeScript versions are
outside the initial support promise. The existing human/public clients remain
available for BusinessMode integrations, but customer backends normally need only
`createMachineClient`.

[Try the live Next.js demo](https://demo.businessmode.io/) ·
[Read its public source](https://github.com/Friggies/businessmode-demo)

The demo currently installs a bundled copy of the earlier preview candidate. It
shows real redemption and access checks against BusinessMode staging without a
separate application database. Its browser-local tasks are not protected server
data; a real product performs its protected operation on the server.

## Set up your project

1. Create a BusinessMode Project and an Entitlement such as `todo:write`.
2. Create an Organization and an active License granting that entitlement, with
   sufficient seats. For redemption, create an Access Code on that License.
3. Create a machine API key for the same Project. Store it in your server's secret
   environment, never in client code or a `NEXT_PUBLIC_` variable.
4. Configure the API URL, including `/v1`. Keep staging and production keys,
   projects, and URLs together; they are separate environments.

```sh
BUSINESSMODE_API_URL=https://api.businessmode.io/v1
BUSINESSMODE_API_KEY=<your-project-machine-key>
```

For staging, use `https://staging-api.businessmode.io/v1` and a staging key. The
hosted demo uses staging. Use an API deployment compatible with the SDK's generated
contract; publishing an SDK does not deploy new API features.

## Quickstart: check access on your server

```ts
import { createMachineClient, getRequestId } from "@businessmode/sdk";

const apiKey = process.env.BUSINESSMODE_API_KEY;
const baseUrl = process.env.BUSINESSMODE_API_URL;
if (!apiKey || !baseUrl) throw new Error("BusinessMode server configuration is missing");

const businessmode = createMachineClient({ baseUrl, apiKey });

export async function canEditTasks(externalUserId: string): Promise<boolean> {
  const result = await businessmode.GET("/access", {
    params: { query: { externalUserId, entitlementKey: "todo:write" } },
    signal: AbortSignal.timeout(10_000),
  });
  if (result.error !== undefined) {
    throw new Error(
      `BusinessMode access check failed (${result.response.status}); request ${getRequestId(result.response) ?? "unknown"}`,
    );
  }
  return result.data?.hasAccess === true;
}
```

Derive `externalUserId` from **your authenticated server session**, not an ID
submitted by the browser. It must be the same stable ID used when assigning or
redeeming access. Check `canEditTasks` immediately before the protected server
operation. A `false` decision denies access; an exception means the check failed
and must not grant access. The SDK does not authenticate your application's users.

For Next.js, keep this client in a server-only module, Route Handler or Server
Action. Pass user-facing results to the browser, not the machine key.

## Redeem an access code or promo code

Using the same server client:

```ts
export async function redeemCode(externalUserId: string, submittedCode: string) {
  const result = await businessmode.POST("/access-codes/redeem", {
    body: { code: submittedCode, externalUserId },
    signal: AbortSignal.timeout(10_000),
  });
  if (result.error !== undefined || !result.data) {
    throw new Error(
      `BusinessMode redemption failed (${result.response.status}); request ${getRequestId(result.response) ?? "unknown"}`,
    );
  }
  return result.data;
}
```

Accept the code from your UI, but derive the user ID from the server session.
Then check the entitlement before granting access. Redemption and access checks
use the same endpoints for generated codes and readable promo codes. Strings are
sent exactly as supplied: no trimming, case conversion, or complexity rules are
added by the SDK. `TRY_BUSINESSMODE` belongs to the hosted demo's staging project;
it is not a universal code for other projects.

Retry an uncertain redemption with the **same code and user ID**. Redemption is
domain-idempotent and does not receive an automatic `Idempotency-Key`. A new user
ID represents another visitor and may consume another seat/redemption allowance.

## Assign and release a seat

```ts
import { createIdempotencyKey } from "@businessmode/sdk";

export async function assignSeat(
  licenseId: string,
  externalUserId: string,
  retryKey: string,
) {
  return businessmode.POST("/licenses/{licenseId}/assignments", {
    params: { path: { licenseId } },
    headers: { "Idempotency-Key": retryKey },
    body: { externalUserId },
    signal: AbortSignal.timeout(10_000),
  });
}

// Create once for a logical operation; retain it with that operation if retried.
const retryKey = createIdempotencyKey();

export async function releaseSeat(licenseId: string, assignmentId: string) {
  return businessmode.DELETE("/licenses/{licenseId}/assignments/{assignmentId}", {
    params: { path: { licenseId, assignmentId } },
    signal: AbortSignal.timeout(10_000),
  });
}
```

These functions return the SDK result: check `error` before treating the operation
as successful. Keep the assignment ID returned by an assignment/redemption if you
need to release that seat later. Releasing a seat does not reset a code's historical
redemption allowance. Guest-session expiry in your app does not release a seat.

For covered create operations, the SDK generates a fresh UUID key when none is
provided. It **never automatically retries**. For an uncertain mutation, reuse the
same explicit key, endpoint, user identity and payload; calling again without an
explicit key creates a new key. Checkout uses this explicit retry pattern too.
Invitation and access-code redemption are domain-idempotent; Billing Portal sessions
are intentionally fresh. The API defines which operations support idempotency.

## Errors, timeouts and timestamps

- HTTP failures return `{ error, response }`; transport failures, cancellation,
  credential validation and redirect rejection throw. Handle both paths.
- An access response with `hasAccess: false` is a valid denial, not an SDK failure.
- `getRequestId(response)` reads `X-Request-Id`. For support, share that ID, the SDK
  version and HTTP status. Do not log credentials, cookies, raw codes or full request
  objects. Respect `Retry-After` on rate-limit responses.
- Supply an `AbortSignal` for your own deadline. The SDK has no default timeout,
  retry worker or background refresh. An aborted mutation may already have reached
  the server, so retain its explicit retry key or domain-idempotent identity.
- Send timestamps with an explicit offset, such as `2027-01-01T00:15:00+05:45` or
  `2026-12-31T18:30:00Z`. The SDK forwards them unchanged and never guesses a timezone.
  Convert local calendar inputs to an unambiguous instant in your application.

## Authentication and security boundaries

| Factory | Authentication | Typical use |
| --- | --- | --- |
| `createMachineClient` | Project machine key | Customer backends checking/granting access |
| `createHumanClient` | Token callback, called before every request | BusinessMode account administration |
| `createPublicClient` | No SDK-provided authorization header | Public API endpoints |

Human clients accept `getAccessToken: () => string | Promise<string>`. Your auth
integration is responsible for obtaining and refreshing a valid BusinessMode user
token. The SDK does not require customers to adopt Supabase for their own users.
Factories choose authentication, not permissions: the API authorizes every request,
and generated route types are not an authorization boundary.

Authenticated clients reject cross-origin request overrides before reading or
attaching credentials, reject empty credentials, refuse redirects and use
`cache: "no-store"`. Configure the final API URL; use a separate client for another
origin. These protections also apply when individual requests ask to follow a
redirect or use a fetch cache. They do not disable a custom HTTP proxy's cache.

Use HTTPS for remote API calls. Explicit HTTP URLs remain available for local or
trusted internal deployment networks; the SDK does not upgrade them automatically.
Treat `baseUrl`, custom `fetch`, serializers and middleware as trusted application
configuration, never visitor input. Custom transport/middleware code can inspect
or alter requests and must preserve these guarantees. This is not a sandbox against
untrusted code running inside your server.

Keep keys in a secret store, separate projects/environments, and rotate or revoke a
key in BusinessMode if it is exposed. The SDK does not log, persist credentials,
start timers, or provide webhook-signature verification or an application rate
limiter. License, seat, expiry and payment rules remain on the API.

## Types, helpers and support

```ts
import type { paths, components, operations } from "@businessmode/sdk";
import type { paths as ApiPaths } from "@businessmode/sdk/types";
import { exactStripeAmount, paymentAmount } from "@businessmode/sdk";
```

`exactStripeAmount("12.50", "usd")` returns `1250` minor units;
`paymentAmount("1250", "usd")` returns `"$12.50"`. Invalid or unsupported charge
amounts throw. These helpers format/convert amounts; the provider validates payment
eligibility and limits.

Preview versions may break compatibility. Pin exact versions and read
[CHANGELOG.md](./CHANGELOG.md) before upgrading. We support the current preview,
without parallel long-term release branches. Use your existing BusinessMode support
channel for integration issues and confidential security reports; do not post secrets
in public issues.

The SDK has one direct runtime dependency, `openapi-fetch` (which also uses
`openapi-typescript-helpers`). It has no private workspace runtime dependencies or
install-time scripts. The private source monorepo can remain private; the public
package includes compiled JavaScript, declarations, this README, changelog and the
[ISC license](./LICENSE). Merging application changes does not publish the SDK.
